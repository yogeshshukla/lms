
MENU ADMIN PER MENU
http://drupal.org/project/menu_admin_per_menu

DESCRIPTION
By default, Drupal 7 allows only users with "Administer menus and menu items" to add, modify or delete menu items.
In case you want for instance to let certain users manage Main menu or Navigation menu but not Management menu, this module provides this functionality.

INSTALLATION
Please read instructions at: http://drupal.org/project/menu_admin_per_menu

CONTACT
Henri MEDOT <henri.medot[AT]absyx[DOT]fr>
http://www.absyx.fr
